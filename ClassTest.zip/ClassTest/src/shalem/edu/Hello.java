package shalem.edu;

public class Hello {
	float f;
    int j;
    String s;
    char ch;
  
    public static void main(String[] args) {
        Hello ob=new Hello();
      
       
        System.out.println("j="+ob.j); 
        System.out.println("s="+ob.s); 
        System.out.println("ch="+ob.ch);
        System.out.println("f="+ob.f); 
	
		    
		    }
       	
    
     
   
    
	}


