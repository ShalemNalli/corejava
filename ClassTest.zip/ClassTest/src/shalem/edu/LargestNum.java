package shalem.edu;

import java.util.Scanner;

class Large{
	private int n1,n2;
	public void inputData() {
	
	}
	public int largestFun() {
		int l;
		l=(n1>n2)?n1:n2;
		return 1;
	}
	
	}


public class LargestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Large ob=new Large();
		ob.inputData();
		int lar=ob.largestFun();
				System.out.println("largest number :"+lar);

	}

}
