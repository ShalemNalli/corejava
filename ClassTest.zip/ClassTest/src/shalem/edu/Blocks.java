package shalem.edu;

public class Blocks {
static {
	System.out.println("static block");
	
}
{
	System.out.println("normal block");
}
Blocks(){
	System.out.println("constructor block");
}
	public static void main(String[] args) {
		Blocks obj=new Blocks();
	}

}
