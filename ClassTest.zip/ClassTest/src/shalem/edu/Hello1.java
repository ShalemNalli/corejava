package shalem.edu;

public class Hello1 {
	int j; //instance variable
    float f;
    String s;
    char ch;
public Hello1(){  //constructor with no arg
  j=22;
  f=50.6f;
  s="Shalem";
  ch='M';
}
public Hello1(int j, String s,float f, char ch){ //constructor with argument
        this.j=j;
       this.s=s;
       this.f=f;
       this.ch=ch;
}
     

	public static void main(String[] args) {
		Hello1 ob1=new Hello1(); //constructor with no arg
        Hello1 ob=new Hello1(5,"Amritha",46.4f,'F'); //constructor with arg

         int i; //local variable are not initialized
        //System.out.println("i="+i); //error
        System.out.println("j="+ob.j);//0
        System.out.println("s="+ob.s);
        System.out.println("ch="+ob.ch);
        System.out.println("f="+ob.f);
       //System.out.println("i="+i); //error
        System.out.println("j="+ob1.j);//0
        System.out.println("s="+ob1.s);
        System.out.println("ch="+ob1.ch);
        System.out.println("f="+ob1.f);
        

	}

}
