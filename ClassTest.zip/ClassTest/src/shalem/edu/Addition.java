package shalem.edu;
import java.util.Scanner;
class Add{
	private int n1,n2,ans;
	public void accept() {
	
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter the value of n1");
	n1=sc.nextInt();
	System.out.println("enter the value of n2");
	n2=sc.nextInt();
	}
	
	public void addition() {
		ans=n1+n2;
	}
	public void display() {
		System.out.println("the sum of "+n1+" and "+n2 +" is "+ans);
	}
}
public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Add obj=new Add	();
	 obj.accept();
	 obj.addition();
	 obj.display();
	}

 }




